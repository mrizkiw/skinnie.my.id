console.log("Tidak menggunakan javascript karena tidak mengerti");

let score;
if ((true || false) && (false || false)) {
    console.log("It's true");
} else {
    console.log("It's false");
}